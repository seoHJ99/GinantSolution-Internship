package com.com.com.vo;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BoardVO {
	private int no;
	private String writer;
	private String id;
	private String title;
	private String content;
	private LocalDateTime writeDate;
	private LocalDateTime modifyDate;
	private int count;
	private String useYN;
	private int dataCount;
}

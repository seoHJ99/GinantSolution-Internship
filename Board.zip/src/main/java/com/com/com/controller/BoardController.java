package com.com.com.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sound.midi.Soundbank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.com.com.dto.DownloadFileDTO;
import com.com.com.service.BoardService;
import com.com.com.vo.BoardVO;
import com.nexacro.java.xapi.data.DataSet;
import com.nexacro.java.xapi.data.DataTypes;
import com.nexacro.java.xapi.data.PlatformData;
import com.nexacro.java.xapi.data.Variable;
import com.nexacro.java.xapi.data.VariableList;
import com.nexacro.java.xapi.tx.HttpPlatformRequest;
import com.nexacro.java.xapi.tx.HttpPlatformResponse;
import com.nexacro.java.xapi.tx.PlatformException;
import com.nexacro.java.xapi.tx.PlatformResponse;
import com.nexacro.java.xapi.tx.PlatformType;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Controller
public class BoardController {

	@Autowired
	private BoardService boardService;

	@RequestMapping("/nexConn")
	public void nexConn(HttpServletRequest request, HttpServletResponse response) throws PlatformException {
		HttpPlatformRequest req = new HttpPlatformRequest(request);

		PlatformData pdata = new PlatformData();

		List<BoardVO> allBoard = boardService.findAll();
		DataSet dataSet = new DataSet("board");
		dataSet.addColumn("�۹�ȣ", DataTypes.STRING, 30);
		dataSet.addColumn("����", DataTypes.STRING, 30);
		dataSet.addColumn("�ۼ���", DataTypes.STRING, 30);
		dataSet.addColumn("�����", DataTypes.STRING, 30);
		dataSet.addColumn("������", DataTypes.STRING, 30);
		for (int i = 0; i < allBoard.size(); i++) {
			int row = dataSet.newRow();
			dataSet.set(row, "�۹�ȣ", allBoard.get(i).getNo());
			dataSet.set(row, "����", allBoard.get(i).getTitle());
			dataSet.set(row, "�ۼ���", allBoard.get(i).getWriter());
			dataSet.set(row, "�����", allBoard.get(i).getWriteDate());
			dataSet.set(row, "������", allBoard.get(i).getModifyDate());
		}

		pdata.addDataSet(dataSet);

		//////////////////////////////////

		HttpPlatformResponse res = new HttpPlatformResponse(response, req);
		res.setData(pdata);
		try {
			res.sendData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping("/nexa/search")
	public void searchNexa(HttpServletRequest request, HttpServletResponse response) throws PlatformException {
		HttpPlatformRequest req = new HttpPlatformRequest(request);
		PlatformData pdata = new PlatformData();

		req.receiveData();
		pdata = req.getData();

		VariableList varList = pdata.getVariableList();
		String findBy = varList.getString("findBy");
		String startDate = varList.getString("startDate");
		String endDate = varList.getString("endDaate");
		String content = varList.getString("content");

		if ("".equals(startDate) || "undefined".equals(startDate)) {
			startDate = null;
		}
		if ("".equals(endDate) || "undefined".equals(endDate)) {
			endDate = null;
		}
		DataSet dataSet = new DataSet("board");
		dataSet.addColumn("�۹�ȣ", DataTypes.STRING, 30);
		dataSet.addColumn("����", DataTypes.STRING, 30);
		dataSet.addColumn("�ۼ���", DataTypes.STRING, 30);
		dataSet.addColumn("�����", DataTypes.STRING, 30);
		dataSet.addColumn("������", DataTypes.STRING, 30);
		List<BoardVO> list = boardService.findByTitle(findBy, content, startDate, endDate);
		for (int i = 0; i < list.size(); i++) {
			int row = dataSet.newRow();
			dataSet.set(row, "�۹�ȣ", list.get(i).getNo());
			dataSet.set(row, "����", list.get(i).getTitle());
			dataSet.set(row, "�ۼ���", list.get(i).getWriter());
			dataSet.set(row, "�����", list.get(i).getWriteDate());
			dataSet.set(row, "������", list.get(i).getModifyDate());
		}
		pdata.addDataSet(dataSet);

		HttpPlatformResponse res = new HttpPlatformResponse(response, req);
		res.setData(pdata);
		try {
			res.sendData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String board(Model model, @RequestParam(value = "page", defaultValue = "1") int page,
			@RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
		List<BoardVO> allList = boardService.findAll();
		int start = (page - 1) * pageSize;
		int end = page * pageSize - 1;
		if (end > allList.size()) {
			end = allList.size();
		}
		int size = allList.size();
		List<BoardVO> newList = allList.subList(start, end);
		Pagination paging = new Pagination(pageSize, page, size);
		model.addAttribute("boardList", newList);
		model.addAttribute("page", paging);
		return "board";
	}

	@RequestMapping(value = "/writing", method = RequestMethod.GET)
	public String writingPage() {
		return "writing";
	}

	@ResponseBody
	@RequestMapping(value = "/writing", method = RequestMethod.POST)
	public String writingAction(HttpServletRequest request,
			@RequestPart(value = "file1", required = false) List<MultipartFile> file1) {
		int seq = boardService.insertBoard(request);
		if (file1.size() > 1) {
			boardService.insertFile(file1, seq);
		}
		return "0";
	}

	@RequestMapping(value = "/board/{no}", method = RequestMethod.GET)
	public String seeBoard(Model model, @PathVariable("no") int no) {
		Map<String, Object> board = boardService.findOneBoard(no);
		List<DownloadFileDTO> fileDtoList = boardService.findFileDTO(no);
		model.addAttribute("board", board);
		model.addAttribute("seq", no);
		model.addAttribute("fileList", fileDtoList);
		return "writing";
	}

	@ResponseBody
	@RequestMapping(value = "/board/{no}", method = RequestMethod.POST)
	public String modifyBoard(Model model, @PathVariable("no") int no, HttpServletRequest request) {
		boardService.modifyBoard(no, request);
		return "0";
	}

	@ResponseBody
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String delete(HttpServletRequest request, Model model, @RequestParam("data") List<String> noList) {
		boardService.delete(noList);
		return "0";
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(Model model, String findBy, String content, String startDate, String endDate,
			@RequestParam(value = "page", defaultValue = "1") int page,
			@RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
		if ("".equals(startDate)) {
			startDate = null;
		}
		if ("".equals(endDate)) {
			endDate = null;
		}

		List<BoardVO> list = boardService.findByTitle(findBy, content, startDate, endDate);
		int start = (page - 1) * pageSize;
		int end = page * pageSize;
		if (end > list.size()) {
			end = list.size();
		}
		int fullSize = list.size();
		List<BoardVO> newList = null;
		if (end > fullSize) {
			newList = list.subList(start, fullSize - 1);
		} else {
			newList = list.subList(start, end);
		}
		model.addAttribute("boardList", newList);
		Pagination paging = new Pagination(pageSize, page, list.size());
		model.addAttribute("page", paging);
		model.addAttribute("content", content);
		return "/board";
	}

	@RequestMapping(value = "/search/ajax", method = RequestMethod.GET)
	public String ajaxSearch(Model model, String findBy, String content, String startDate, String endDate,
			@RequestParam(value = "page", defaultValue = "1") int page,
			@RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
		if ("".equals(startDate)) {
			startDate = null;
		}
		if ("".equals(endDate)) {
			endDate = null;
		}
		int start = (page - 1) * pageSize + 1;
		int end = page * pageSize;
		List<BoardVO> list = boardService.findWithAjax(findBy, content, startDate, endDate, start, end);
		model.addAttribute("boardList", list);
		Pagination paging = new Pagination(pageSize, page, list.get(0).getDataCount());
		model.addAttribute("page", paging);
		return "/ajax/boardList";
	}

	@RequestMapping(value = "/download/{realName}", method = RequestMethod.GET)
	public void downloadFile(@RequestParam("listSeq") int listSeq, @PathVariable("realName") String realName,
			HttpServletResponse response) throws IOException {
		File file = boardService.findDownloadFile(listSeq, realName);
		response.setContentType("application/download");
		response.setContentLength((int) file.length());
		response.setHeader("Content-disposition", "attachment;filename=\"" + realName + "\"");

		OutputStream os = response.getOutputStream();
		FileInputStream fis = new FileInputStream(file);
		FileCopyUtils.copy(fis, os);
		fis.close();
		os.close();
	}

}

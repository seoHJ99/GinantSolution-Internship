package com.com.com.dto;

import java.time.LocalDate;

import lombok.Getter;

@Getter
public class DownloadFileDTO {
	private int fileSeq;
	private String realName;
	private String saveName;
	private LocalDate regDate;
	private String savePath;
	private int listSeq;
}

package com.com.com.dto;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import lombok.Data;

@Data
public class BoardDTO {
	private int no;
	private String writer;
	private String id;
	private String title;
	private String content;
	private LocalDateTime writeDate;
	private LocalDateTime modifyDate;
	private int count;
	private String aaa;
	private int seq;
	
	public BoardDTO(HttpServletRequest request) {
		this.id = request.getParameter("id");
		this.writer = request.getParameter("writer");
		this.title = request.getParameter("title");
		this.content = request.getParameter("content");
		this.writeDate = LocalDateTime.now();
	}
}

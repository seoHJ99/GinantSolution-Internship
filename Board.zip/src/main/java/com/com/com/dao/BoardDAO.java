package com.com.com.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.com.com.dto.BoardDTO;
import com.com.com.dto.DownloadFileDTO;
import com.com.com.mapper.BoardMapper;
import com.com.com.vo.BoardVO;

import oracle.net.aso.e;

@Repository
public class BoardDAO implements DAOInter {

	@Autowired
	private SqlSession sqlSession;

	@Autowired
	private BoardMapper mapper;
	
	public List<BoardVO> findAll() {
		return mapper.findAll();
	}


	@Override
	public int insert(BoardDTO dto) {
//		BoardMapper mapper = sqlSession.getMapper(BoardMapper.class);
		int seq = mapper.insert(dto);
		return seq;
	}

	@Override
	public Map<String, Object> findOne(int no) {
		Map<String, Object> map = mapper.findOne(no);
		return map;
	}

	@Override
	public void modifyBoard(Map<String, Object> map) {
//		BoardMapper mapper2 = sqlSession.getMapper(BoardMapper.class);
		map.put("modifyDate", LocalDateTime.now());
		mapper.modifyBoard(map);
	}

	@Override
	public void delete(List<String> noList) {
		String noString = "";
		for (int i = 0; i < noList.size(); i++) {
			if (i == 0) {
				noString += noList.get(i);
			}else {
				noString +="," + noList.get(i);
			}
		}
		mapper.delete(noList);
	}
	
	@Override
	public List<BoardVO> findByTitle(String findBy, String content, String startDate, String endDate){
		return mapper.findByTitle(findBy, content, startDate, endDate);
	}
	
	@Override
	public List<BoardVO> findWithAjax(String findBy, String content, String startDate, String endDate, int start, int end){
		return mapper.findWithAjax(findBy, content, startDate, endDate, start, end);
	}
	
	@Override
	public void insertFile(Map<String, Object> map) {
		mapper.insertFile(map);
	}
	
	@Override
	public List<DownloadFileDTO> findFileDTO(int listSeq) {
		return mapper.findFile(listSeq);
	}
}

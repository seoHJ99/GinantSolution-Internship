package com.com.com.dao;

import java.util.List;
import java.util.Map;

import com.com.com.dto.BoardDTO;
import com.com.com.dto.DownloadFileDTO;
import com.com.com.vo.BoardVO;

public interface DAOInter {
	List<BoardVO> findAll();
	List<BoardVO> findWithAjax(String findBy, String content, String startDate, String endDate, int start, int end);
	int insert(BoardDTO boardDTO);
	Map<String, Object> findOne(int no);
	void modifyBoard(Map<String, Object> map);
	void delete(List<String> noList);
	List<BoardVO> findByTitle(String findBy, String content, String startDate, String endDate);
	void insertFile(Map<String, Object> map);
	List<DownloadFileDTO> findFileDTO(int listSeq);
}

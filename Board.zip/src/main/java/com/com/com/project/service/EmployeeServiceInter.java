package com.com.com.project.service;

public interface EmployeeServiceInter {

}

package com.com.com.service;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.com.com.dao.DAOInter;
import com.com.com.dto.BoardDTO;
import com.com.com.dto.DownloadFileDTO;
import com.com.com.vo.BoardVO;

import jdk.internal.org.objectweb.asm.tree.IntInsnNode;
import oracle.net.aso.f;

@Service
public class BoardService implements ServiceInter {
	
	@Autowired
	private DAOInter boardDAO;
	
	@Override
	public List<BoardVO> findAll(){
		return boardDAO.findAll();
	}
	
	@Override
	public int insertBoard(HttpServletRequest request) {
		BoardDTO boardDTO = new BoardDTO(request);
		 boardDAO.insert(boardDTO);
		return boardDTO.getSeq();
	}
	
	@Override
	public Map<String, Object> findOneBoard(int no){
		
		return boardDAO.findOne(no);
	}
	
	@Override
	public void modifyBoard(int no, HttpServletRequest request) {
		Map<String, Object> map = mapConverter(request);
		map.put("no", no);
		boardDAO.modifyBoard(map);
	}
	
	public Map<String, Object> mapConverter(HttpServletRequest request){
	    Map<String, Object> map = new HashMap<String, Object>();
	    
	    Enumeration<String> enumber = request.getParameterNames();
	    
	    while (enumber.hasMoreElements()) {
	        String key = enumber.nextElement().toString();
	        String value = request.getParameter(key);
	        map.put(key, value);  
	    }
        return map;
	}
	
	@Override
	public void delete(List<String> noList) {
		boardDAO.delete(noList);
	}
	
	@Override
	public List<BoardVO> findByTitle(String findBy, String content, String startDate, String endDate){
			return boardDAO.findByTitle(findBy, content, startDate, endDate);	
	}
	
	@Override
	public List<BoardVO> findWithAjax(String findBy, String content, String startDate, String endDate, int start, int end){
			return boardDAO.findWithAjax(findBy, content, startDate, endDate, start, end);
	}
	
	@Override
	public void insertFile(List<MultipartFile> files, int seq) {
		String uploadPath = "C:\\Users\\dev\\Desktop\\fileUpload\\";
		for(int i =0; i<files.size(); i++) {
		      MultipartFile myFile= files.get(i);
		      String originName = myFile.getOriginalFilename();
		      UUID uuid = UUID.randomUUID();
		      String uniqueName = uuid +"_"+originName;
		      String savePath = uploadPath + uuid +"_"+originName;
		      try {
			      myFile.transferTo(new File(savePath));
			      Map<String, Object> map = new HashMap<String, Object>();
			      map.put("realName", originName);
			      map.put("savedName", uniqueName);
			      map.put("savePath", uploadPath);
			      map.put("regDate", LocalDate.now());
			      map.put("listSeq", seq);
			      boardDAO.insertFile(map);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
	
	@Override
	public List<DownloadFileDTO> findFileDTO(int listSeq){
		return  boardDAO.findFileDTO(listSeq);
	}
	
	@Override
	public File findDownloadFile(int listSeq, String realName){
		List<DownloadFileDTO> dtoList = findFileDTO(listSeq);
		File file = null;
		for(int i =0; i<dtoList.size(); i++) {
			DownloadFileDTO dto = dtoList.get(i);
			String downPath = dto.getSavePath();
			String realNameDto = dto.getRealName();
			String saveName = dto.getSaveName();
		if(realNameDto.equals(realName)) {
			file = new File(downPath + saveName);
			}
		}
		return file;
	}
}

package com.com.com.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.com.com.dto.DownloadFileDTO;
import com.com.com.vo.BoardVO;

public interface ServiceInter {
	List<BoardVO> findAll();
	List<BoardVO> findByTitle(String findBy, String searchCon, String startDate, String endDate);
	List<BoardVO> findWithAjax(String findBy, String searchCon, String startDate, String endDate, int start, int end);
	int insertBoard(HttpServletRequest request);
	Map<String, Object> findOneBoard(int no);
	void modifyBoard(int no, HttpServletRequest request);
	void delete(List<String> noList);
	void insertFile(List<MultipartFile> file, int seq);
	List<DownloadFileDTO> findFileDTO(int listSeq);
	File findDownloadFile(int listSeq, String realName);
}

package com.com.com;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import com.com.com.mapper.BoardMapper;
import com.com.com.project.ProjectAop;

@Configuration
public class AppConfig {
	
	@Autowired
	private SqlSession sqlSession;
	
	@Bean
	public BoardMapper boardMapper() {
		BoardMapper mapper = sqlSession.getMapper(BoardMapper.class);
		return mapper;
	}
	
    @Bean
    public ProjectAop timeTraceAop() {
        return new ProjectAop();
    }
}
